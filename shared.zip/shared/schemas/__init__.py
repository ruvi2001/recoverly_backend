# Common schemas
