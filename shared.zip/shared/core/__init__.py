# Core utilities
