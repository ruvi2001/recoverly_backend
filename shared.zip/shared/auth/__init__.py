# Authentication utilities
